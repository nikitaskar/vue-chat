<template>
  <li>
    {{data}}
  </li>
</template>

<script type="text/javascript">
  export default {
    props: ['data']
  }
</script>
