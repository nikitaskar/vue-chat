<template>
  <article>
    {{ data }}
  </article>
</template>

<script type="text/javascript">
  export default {
    props: ['data']
  }

</script>

<style lang="stylus">
article
  width auto;
  max-width 200px
  font-family Arial
  color white
  background #ffc12d
  padding 10px
  border-radius 5px

</style>
